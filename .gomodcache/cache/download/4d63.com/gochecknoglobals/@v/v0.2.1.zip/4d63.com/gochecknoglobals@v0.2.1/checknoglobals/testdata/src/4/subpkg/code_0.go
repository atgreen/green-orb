package code

func someCode() bool {
	return true
}

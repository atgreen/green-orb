package code_test

var myTestVar = 0 // want "myTestVar is a global variable"

package customDecOrderAll

type ad int

func aa() {}

const ab = 1

var ac = 1

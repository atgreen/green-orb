package customDecOrderAll

var _ = 1

var a = 1

var _ = 1

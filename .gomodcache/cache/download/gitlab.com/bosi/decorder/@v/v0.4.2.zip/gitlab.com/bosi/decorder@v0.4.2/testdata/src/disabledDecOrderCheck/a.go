package disabledDecOrderCheck

func ca() {}

type cc int

const cd = 1

var ce = 1

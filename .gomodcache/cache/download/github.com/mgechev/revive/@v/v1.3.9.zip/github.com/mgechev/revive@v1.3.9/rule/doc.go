// Package rule implements revive's linting rules.
package rule

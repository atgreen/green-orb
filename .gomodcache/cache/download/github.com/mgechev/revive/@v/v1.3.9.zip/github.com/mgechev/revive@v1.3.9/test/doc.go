// Package test implements rule tests.
package test

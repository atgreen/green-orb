package fixtures

func funLengthA() (a int) {
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
	println()
}

//revive:disable
//nolint:dupl,revive // looks the same but isn't
//revive:enable

package foo // MATCH /should have a package comment/

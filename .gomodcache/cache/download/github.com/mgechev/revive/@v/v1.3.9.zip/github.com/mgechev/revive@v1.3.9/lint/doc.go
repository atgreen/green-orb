// Package lint implements the linting machinery.
package lint

# Security Policy

## Reporting a Vulnerability

Please open a [github issue](https://github.com/ckaznocha/intrange/issues)

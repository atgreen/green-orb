// Package meta provides functionality to parse and manage metadata information
// for Shoutrrr using Go's debug.ReadBuildInfo and GoReleaser build flags.
package meta

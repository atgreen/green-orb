# Email

## URL Format

!!! info ""
    smtp://__`username`__:__`password`__@__`host`__:__`port`__/?fromaddress=__`fromAddress`__&toaddresses=__`recipient1`__[,__`recipient2`__,...]&subject=__`subject`__&auth=__`auth`__&encryption=__`encryption`__&useStartTLS=__`yes/no`__&useHTML=__`yes/no`__&clientHost=__`hostname`__&requirestarttls=__`yes/no`__&timeout=__`duration`__

--8<-- "docs/services/smtp/config.md"

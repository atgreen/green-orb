package standard

// Standard implements the Logger and Templater parts of the Service interface.
type Standard struct {
	Logger
	Templater
}

# Bark

Upstream docs: https://github.com/Finb/Bark

## URL Format

--8<-- "docs/services/bark/config.md"
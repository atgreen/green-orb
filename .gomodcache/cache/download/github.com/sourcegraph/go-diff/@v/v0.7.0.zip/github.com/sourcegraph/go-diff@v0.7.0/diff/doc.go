// Package diff provides a parser for unified diffs.
package diff

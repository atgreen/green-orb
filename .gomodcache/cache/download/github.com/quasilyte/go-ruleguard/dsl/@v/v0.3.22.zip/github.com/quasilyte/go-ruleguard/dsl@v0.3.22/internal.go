package dsl

var boolResult bool
var intResult int

var underlyingType ExprType

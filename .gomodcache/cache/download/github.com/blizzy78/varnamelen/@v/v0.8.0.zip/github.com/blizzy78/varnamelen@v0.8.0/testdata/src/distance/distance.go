package distance

func Variable() {
	x := 123
	_ = x
}

func Param(x int) {
	_ = x
}

// Package varnamelen implements an analyzer checking that the length of a variable's name
// matches its usage scope.
package varnamelen

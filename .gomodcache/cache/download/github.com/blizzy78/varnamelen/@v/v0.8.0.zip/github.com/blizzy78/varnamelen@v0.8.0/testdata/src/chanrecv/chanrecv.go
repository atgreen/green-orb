package chanrecv

func ChanRecvOK() {
	_, ok := <-make(chan int)
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = ok
}

package distancereturn

func Return() (x int) {
	x = 123
	return
}

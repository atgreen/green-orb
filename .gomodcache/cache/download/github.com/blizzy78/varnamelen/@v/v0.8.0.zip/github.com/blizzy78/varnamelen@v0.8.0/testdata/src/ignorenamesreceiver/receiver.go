package warningsreceiver

type foo struct{}

func (f *foo) Receiver() {
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = f
}

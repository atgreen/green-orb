package mapindex

func MapIndexOK() {
	_, ok := map[int]int{}[0]
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = ok
}

package ignoredeclsreturn

func Return() (i int) {
	// fill
	// fill
	// fill
	// fill
	// fill
	i = 123
	return
}

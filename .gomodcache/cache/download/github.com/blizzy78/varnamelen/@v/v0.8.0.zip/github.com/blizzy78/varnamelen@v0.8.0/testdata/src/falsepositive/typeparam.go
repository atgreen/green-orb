package falsepositive

func TypeParam[T any]() {
	// fill
	// fill
	// fill
	// fill
	// fill
	var t T
	_ = t
}

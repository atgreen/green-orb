package namelenreturn

func Return() (longName int) {
	// fill
	// fill
	// fill
	// fill
	// fill
	longName = 123
	return
}

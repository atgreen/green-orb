package namelen

func Variable() {
	longName := 123
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = longName
}

func Param(longName int) {
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = longName
}

package warnings

const I = 123 // want `constant name 'I' is too short for the scope of its usage`

func Const() {
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = I
}

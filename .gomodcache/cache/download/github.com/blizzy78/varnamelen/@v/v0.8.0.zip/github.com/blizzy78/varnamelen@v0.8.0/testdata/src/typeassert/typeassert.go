package typeassert

func TypeAssertOK() {
	_, ok := interface{}(1).(int)
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = ok
}

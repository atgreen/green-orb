package ignorenames

const I = 123

func Const() {
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = I
}

func Variable() {
	i := 123
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = i
}

func Param(i int) {
	// fill
	// fill
	// fill
	// fill
	// fill
	_ = i
}

* Arthur Silva Sens <arthursens2005@gmail.com> @ArthurSens
* Bartłomiej Płotka <bwplotka@gmail.com> @bwplotka
* Kemal Akkoyun <kakkoyun@gmail.com> @kakkoyun

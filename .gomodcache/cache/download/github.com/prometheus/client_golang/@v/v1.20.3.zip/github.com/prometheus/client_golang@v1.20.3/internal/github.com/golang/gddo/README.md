This source code is a stripped down version from the archived repository https://github.com/golang/gddo and licensed under BSD.

* Johannes 'fish' Ziemke <github@freigeist.org> @discordianfish
* Paul Gier <paulgier@gmail.com> @pgier
* Ben Kochie <superq@gmail.com> @SuperQ

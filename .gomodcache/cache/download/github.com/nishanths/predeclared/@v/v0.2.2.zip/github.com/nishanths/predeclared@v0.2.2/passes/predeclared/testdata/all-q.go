//predeclared -q

package rune

import false "example.org/f"

const (
	nil      T = true
	len, cap   = 1, 100
)

var (
	int8 T = 42
)

const int = "hello"

var (
	ok = func() T {
		new := N()
		return new
	}()
	nok = func() T {
		type byte struct{}
		return (byte)(nil)
	}()
)

type D struct {
	print func(float64 F) (float64, float32 F)
}

type I interface {
	uintptr(int32 Ptr) (int16 Ptr)
}

func println() {
	var close = "NOPE"
	const delete = struct{}{}
	{
		iota := 1
	}
imag:
	for range a {
	real:
		select {
		case b:
			break real
		}
		break imag
	}
	type DD struct {
		complex128, complex64 C
	}
}

func (error E) complex64(string MyString) (byte MyByte) {
	panic, recover := p(), r()
	f := func() {
		make := 3
	}
	return
}

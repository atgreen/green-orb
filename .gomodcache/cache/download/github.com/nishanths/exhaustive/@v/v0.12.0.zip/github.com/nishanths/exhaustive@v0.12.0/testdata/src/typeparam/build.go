package typeparam

// This file exists so that the package (which, otherwise, consists only of
// go1.18 files) can build with all go versions.

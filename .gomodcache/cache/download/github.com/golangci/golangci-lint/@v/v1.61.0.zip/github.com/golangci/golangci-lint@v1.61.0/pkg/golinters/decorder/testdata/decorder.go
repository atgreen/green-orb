//golangcitest:args -Edecorder
//golangcitest:expected_exitcode 0
package testdata

import "math"

const (
	decoh = math.MaxInt64
	decoi = 1
)

var decoj = 1
var decok = 1

type decol int

func decom() {
	const decon = 1
}

func init() {}

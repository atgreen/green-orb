package main

// This file is used to declare module plugins.

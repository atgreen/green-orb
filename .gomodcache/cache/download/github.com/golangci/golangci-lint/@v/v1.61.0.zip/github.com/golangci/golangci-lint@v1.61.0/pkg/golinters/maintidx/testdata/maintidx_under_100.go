//golangcitest:args -Emaintidx
//golangcitest:config_path testdata/maintidx_under_100.yml
package testdata

func over20() { // want "Function name: over20, Cyclomatic Complexity: 1, Halstead Volume: 8.00, Maintainability Index: 86"
}

func under20() { // want "Function name: under20, Cyclomatic Complexity: 76, Halstead Volume: 1636.00, Maintainability Index: 17"
	for true {
		if false {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		} else if false {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		} else if false {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		} else if false {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		} else {
			if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else if false {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			} else {
				n := 0
				switch n {
				case 0:
				case 1:
				default:
				}
			}
		}
	}
}

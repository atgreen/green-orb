/*MY TITLE.*/

//golangcitest:args -Egoheader
//golangcitest:config_path testdata/goheader.yml
//golangcitest:expected_exitcode 0
package testdata

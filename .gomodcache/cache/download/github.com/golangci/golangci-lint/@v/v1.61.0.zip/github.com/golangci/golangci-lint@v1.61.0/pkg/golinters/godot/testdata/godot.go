//golangcitest:args -Egodot
package testdata

// Godot checks top-level comments // want "Comment should end in a period"
func Godot() {
	// nothing to do here
}

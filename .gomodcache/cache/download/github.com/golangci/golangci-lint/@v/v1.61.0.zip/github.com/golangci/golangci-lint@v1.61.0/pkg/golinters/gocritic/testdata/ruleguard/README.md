This directory contains ruleguard files that are used in functional tests.

Helpful:

- https://go-critic.com/overview.html
- https://github.com/go-critic/go-critic/blob/master/checkers/rules/rules.go

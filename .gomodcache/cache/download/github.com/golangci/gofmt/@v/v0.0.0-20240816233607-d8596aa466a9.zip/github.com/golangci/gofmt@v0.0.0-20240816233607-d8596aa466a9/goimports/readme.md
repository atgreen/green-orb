# Hard Fork of goimports

- https://github.com/golang/tools/tree/master/cmd/goimports

## Updates

- 2024-08-17: Sync with golang.org/x/tools v0.24.0
- 2024-02-28: Sync with golang.org/x/tools v0.18.0
- 2023-10-04: Sync with golang.org/x/tools v0.13.0
- 2022-08-31: Sync with golang.org/x/tools v0.1.12

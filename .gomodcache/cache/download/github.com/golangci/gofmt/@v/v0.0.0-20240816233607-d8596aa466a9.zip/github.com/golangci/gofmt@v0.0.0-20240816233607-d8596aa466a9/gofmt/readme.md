# Hard Fork of gofmt

- https://github.com/golang/go/blob/master/src/cmd/gofmt/
- https://github.com/golang/go/blob/master/src/internal/testenv
- https://github.com/golang/go/blob/master/src/internal/platform
- https://github.com/golang/go/blob/master/src/internal/txtar
- https://github.com/golang/go/blob/master/src/internal/diff
- https://github.com/golang/go/blob/master/src/internal/cfg

## Updates

- 2024-08-17: Sync with go1.22.6
- 2023-02-28: Sync with go1.21.7
- 2023-10-04: Sync with go1.20.8
- 2023-10-04: Sync with go1.19.13
- 2022-08-31: Sync with go1.18.5

package e

import "errors"

var (
	ErrE = errors.New("e")
)

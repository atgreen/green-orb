package d

import "errors"

var ErrD = errors.New("d")

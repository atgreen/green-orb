package main

var golangCILintVer = "v1.48.0"
var goReleaserVer = "v1.10.3"
var gosImportsVer = "v0.1.5"

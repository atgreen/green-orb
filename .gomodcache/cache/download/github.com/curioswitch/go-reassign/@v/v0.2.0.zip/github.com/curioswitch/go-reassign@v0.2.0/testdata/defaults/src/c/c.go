package c

import "errors"

var (
	ErrC = errors.New("c")
)

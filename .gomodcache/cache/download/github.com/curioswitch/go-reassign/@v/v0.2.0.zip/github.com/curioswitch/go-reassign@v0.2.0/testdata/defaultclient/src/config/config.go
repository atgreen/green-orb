package config

import "net/http"

var DefaultClient = &http.Client{}

package onepkg

func Stuff() {}

package node

type Node struct {
	ID    int
	Value any
}

type NodeOrderedSet []Node

package testcase

import "fmt" // want "should only use grouped 'import' declarations"

func dummy() { fmt.Println("dummy") }

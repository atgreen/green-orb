package testdata

func op2or() {
	_ = true || true
}

func op2and() {
	_ = true && true
}

func op3mixed() {
	_ = true || true && true
}

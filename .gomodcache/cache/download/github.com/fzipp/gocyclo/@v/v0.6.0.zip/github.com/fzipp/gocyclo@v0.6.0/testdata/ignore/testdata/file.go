package testdata

func a() {}

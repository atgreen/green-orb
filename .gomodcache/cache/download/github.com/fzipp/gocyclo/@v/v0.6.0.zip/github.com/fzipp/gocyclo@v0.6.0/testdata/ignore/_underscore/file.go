package underscore

func a() {}

package directory

func b() {}

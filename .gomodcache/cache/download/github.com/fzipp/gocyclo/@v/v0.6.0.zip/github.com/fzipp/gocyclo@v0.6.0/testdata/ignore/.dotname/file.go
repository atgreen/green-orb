package dotname

func a() {}

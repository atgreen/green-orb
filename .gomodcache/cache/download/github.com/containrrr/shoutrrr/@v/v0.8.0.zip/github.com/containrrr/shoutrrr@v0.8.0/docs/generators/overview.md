# Generators

Generators are used to create service configurations via the command line.  
The main generator is the reflection based [Basic generator](./basic) that aims to be able to generator configurations for all the core services via a set of simple questions.

## Usage

```bash
$ shoutrrr generate [OPTIONS] -g <GENERATOR> <SERVICE>
```
#!/bin/sh

go build -o ./shoutrrr/shoutrrr ./shoutrrr

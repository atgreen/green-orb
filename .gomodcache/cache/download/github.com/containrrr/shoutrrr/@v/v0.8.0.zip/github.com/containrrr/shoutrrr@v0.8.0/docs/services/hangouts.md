# Hangouts Chat

Google Chat was previously known as *Hangouts Chat*. See [Google
Chat](googlechat.md).

Using `hangouts` in the service URL instead `googlechat` is still
supported, although deprecated.

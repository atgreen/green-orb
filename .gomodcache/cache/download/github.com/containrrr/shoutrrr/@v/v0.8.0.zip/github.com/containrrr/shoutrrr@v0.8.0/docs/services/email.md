# Email

## URL Format

!!! info ""
    smtp://__`username`__:__`password`__@__`host`__:__`port`__/?from=__`fromAddress`__&to=__`recipient1`__[,__`recipient2`__,...]

--8<-- "docs/services/smtp/config.md"

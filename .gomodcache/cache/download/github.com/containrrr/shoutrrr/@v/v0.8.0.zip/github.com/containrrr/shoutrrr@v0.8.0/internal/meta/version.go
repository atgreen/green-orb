package meta

// Version of Shoutrrr
const Version = `0.8.0`

// DocsVersion is prepended to documentation URLs and usually equals MAJOR.MINOR of Version
const DocsVersion = `v0.8`

# Pushbullet

## URL Format

!!! info ""
    pushbullet://__`api-token`__[/__`device`__/#__`channel`__/__`email`__]

--8<-- "docs/services/pushbullet/config.md"
package t

import "testing"

func TestAny(t *testing.T) {}

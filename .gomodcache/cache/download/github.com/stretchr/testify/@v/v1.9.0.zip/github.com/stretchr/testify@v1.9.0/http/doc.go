// Deprecated: Use [net/http/httptest] instead.
package http

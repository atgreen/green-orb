# Emeritus

We would like to acknowledge previous testify maintainers and their huge contributions to our collective success:

  * @matryer
  * @glesica
  * @ernesto-jimenez
  * @mvdkleijn
  * @georgelesica-wf
  * @bencampbell-wf

We thank these members for their service to this community.

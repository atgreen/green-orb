// This package exists just to isolate tests that reference the [unsafe] package.
//
// The tests in this package are totally safe.
package unsafetests

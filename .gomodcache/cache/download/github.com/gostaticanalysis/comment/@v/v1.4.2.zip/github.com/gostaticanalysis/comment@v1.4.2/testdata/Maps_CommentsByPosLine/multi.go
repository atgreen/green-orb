-- a.go --
package a

// a
func A() {}
-- b.go --
package a

// b
func B_() {
}

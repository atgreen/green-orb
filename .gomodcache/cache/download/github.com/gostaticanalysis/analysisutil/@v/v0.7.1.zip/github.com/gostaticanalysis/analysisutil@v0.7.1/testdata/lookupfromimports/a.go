package a

import (
	"b"
	"fmt"
)

func F() {
	fmt.Println(b.Msg)
}

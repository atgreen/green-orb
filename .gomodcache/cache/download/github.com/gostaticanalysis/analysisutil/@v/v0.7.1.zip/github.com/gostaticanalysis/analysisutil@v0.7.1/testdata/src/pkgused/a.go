package pkgused

import (
	"b"
	"fmt"
)

func F() {
	fmt.Println(b.Msg)
}
